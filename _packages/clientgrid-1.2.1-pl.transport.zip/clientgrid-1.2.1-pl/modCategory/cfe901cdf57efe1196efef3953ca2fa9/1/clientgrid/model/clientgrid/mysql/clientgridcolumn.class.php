<?php

/**
 * Client Grid
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */
    
require_once dirname(__DIR__) . '/clientgridcolumn.class.php';

class ClientGridColumn_mysql extends ClientGridColumn
{
}
