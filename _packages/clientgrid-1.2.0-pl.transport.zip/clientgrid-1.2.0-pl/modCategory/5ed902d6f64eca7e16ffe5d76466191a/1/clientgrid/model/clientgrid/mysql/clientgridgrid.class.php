<?php

/**
 * Client Grid
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */
    
require_once dirname(__DIR__) . '/clientgridgrid.class.php';

class ClientGridGrid_mysql extends ClientGridGrid
{
}
