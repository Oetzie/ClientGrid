<?php

/**
 * Client Grid
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */
    
require_once dirname(__DIR__) . '/clientgridtab.class.php';

class ClientGridTab_mysql extends ClientGridTab
{
}
