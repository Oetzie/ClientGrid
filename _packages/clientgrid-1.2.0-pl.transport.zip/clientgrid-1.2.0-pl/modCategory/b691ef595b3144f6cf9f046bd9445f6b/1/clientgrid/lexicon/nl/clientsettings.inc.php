<?php

/**
 * Client Grid
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$_lang['clientsettings.clientgrid.name']                        = 'Grid';

$_lang['clientsettings.clientgrid.label_config']                = 'Grid config';
$_lang['clientsettings.clientgrid.label_config_desc']           = 'De grid config voor het grid.';
