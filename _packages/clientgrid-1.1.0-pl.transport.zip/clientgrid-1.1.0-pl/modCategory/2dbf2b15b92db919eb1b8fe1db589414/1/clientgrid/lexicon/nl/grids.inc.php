<?php

/**
 * Client Grid
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$_lang['clientgrid.grid_column_lorem']                          = 'Column lorem ipsum';

$_lang['clientgrid.grid_field_lorem']                           = 'Field lorem ipsum';
$_lang['clientgrid.grid_field_lorem_desc']                      = 'Field lorem ipsum dolor sit amet';

$_lang['clientgrid.grid_tab_lorem']                             = 'Tab lorem ipsum';
$_lang['clientgrid.grid_tab_lorem_desc']                        = 'Tab lorem ipsum dolor sit amet';
