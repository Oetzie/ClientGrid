<?php

/**
 * Client Grid
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */
    
require_once dirname(__DIR__) . '/clientgridfield.class.php';

class ClientGridField_mysql extends ClientGridField
{
}
