----------------------
Client Grid
----------------------
Version: 1.1.0
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------